package com.ram.sms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.util.logging.Logger;
import com.ram.sms.bo.CustomerBO;
import com.ram.sms.model.Customer;

public class CustomerAction implements ModelDriven{
	
	
	Customer customer = new Customer();
	List<Customer> customerList = new ArrayList<Customer>();
	//@Autowired
	CustomerBO customerBO;
	//DI via Spring
	public void setCustomerBO(CustomerBO customerBO) {
		this.customerBO = customerBO;
	}

	public Object getModel() {
		return customer;
	}
	
	public List<Customer> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<Customer> customerList) {
		this.customerList = customerList;
	}

	//save customer
	public String addCustomer() throws Exception{
		System.out.println("Customer action");
		//save it
		
		
		customer.setCreatedDate(new Date());
		customerBO.addCustomer(customer);
	 
		//reload the customer list
		
		customerList = customerBO.listCustomer();
		
		return "success";
	
	}
	
	//list all customers
	public String listCustomer() throws Exception{
		
		customerList = customerBO.listCustomer();
		
		return "success";
	
	}

}
