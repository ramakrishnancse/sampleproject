package com.ram.sms.bo;

import java.util.List;

import com.ram.sms.dao.CustomerDAO;
import com.ram.sms.model.Customer;

public class CustomerBOImpl implements CustomerBO {
	//@Autowired
	CustomerDAO customerDAO;

	public void setCustomerDAO(CustomerDAO customerDAO) {
		this.customerDAO = customerDAO;
	}
	public void addCustomer(Customer customer) {
		System.out.println("Customer BO");
		customerDAO.addCustomer(customer);
	}

	public List<Customer> listCustomer() {
		return customerDAO.listCustomer();
	}

}
