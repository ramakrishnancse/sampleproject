package com.ram.sms.dao;

import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

import com.ram.sms.model.Customer;

public class CustomerDAOImpl extends HibernateDaoSupport implements CustomerDAO {
	
	Session session=null;
	public  void addCustomer(Customer customer) {
		try {
			/*sessionFactory = new Configuration().configure().buildSessionFactory();
		    session = sessionFactory.openSession();
		    session.setFlushMode(FlushMode.AUTO);
		    session.beginTransaction();
		    session.save(customer);
		    session.flush();*/
			System.out.println("Customer DAO");
			
			getHibernateTemplate().setCheckWriteOperations(false);
			/*getHibernateTemplate().persist(customer);
			System.out.println(" ID");
			
			getHibernateTemplate().flush();*/
			
			session = getSessionFactory().openSession();
			session.saveOrUpdate(customer);
			session.flush();
			System.out.println(" after session");
		} catch (HibernateException e) {
		    e.printStackTrace();
		}finally {
			/*if(session !=null)
			session.close();*/
		}
		/*getHibernateTemplate().getSessionFactory().getCurrentSession().setFlushMode(FlushMode.AUTO);
		getHibernateTemplate().save(customer);*/
	}

	public  List<Customer> listCustomer() {
		List<Customer> customerlist = null; 
		try {
			
		/*	sessionFactory = new Configuration().configure().buildSessionFactory();
			
			session = sessionFactory.openSession();
			customerlist = session.createQuery("from Customer").list();
	    */
			//getHibernateTemplate().setCheckWriteOperations(false);
	    customerlist = (List<Customer>) getHibernateTemplate().find("from Customer");
	    getHibernateTemplate().flush();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			/*if(session !=null)
				session.close();*/
		}
		return 	customerlist;
	}

}
