package com.ram.sms.bo;

import java.util.List;

import com.ram.sms.model.Customer;

public interface CustomerBO {
	void addCustomer(Customer customer);
	List<Customer> listCustomer();
}
