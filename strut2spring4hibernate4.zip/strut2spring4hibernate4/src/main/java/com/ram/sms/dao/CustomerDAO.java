package com.ram.sms.dao;



import java.util.List;

import com.ram.sms.model.Customer;

 
public interface CustomerDAO{
	
	void addCustomer(Customer customer);
	List<Customer> listCustomer();	
	
}

